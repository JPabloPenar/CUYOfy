package ProyectoIntegrador;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.swing.SwingUtilities;

public class ProyectoIntegrador1 {
    public static String user = System.getProperty("user.name");
    public static Artista rosalia = new Artista("Rosalía", "Cumbia");
    public static Artista abelPintos = new Artista("Abel Pintos", "Folklore");
    public static Artista fitoPaez = new Artista("Fito Paez", "Rock Nacional");
    public static Artista acdc = new Artista("ACDC", "Rock");
    public static Artista queen = new Artista("Queen", "Rock");
    public static List<Cancion> listaCancionesGlobal = new ArrayList<>();
    public static Map<String, List<Cancion>> cancionesPorGenero = new HashMap<>();
    
    public static void main(String[] args) {
        
        DataBase db= new DataBase();
       
        String url = "jdbc:sqlite:C:/Users/"+user+"/Music/CUYOfy/1DATABASE/mydatabase.db";
        
        db.getConnection();
        //db.borrarTodasLasTablas();
        db.eliminarTodosLosRegistros();
        db.crearPlaylistsIniciales();
        db.crearTablas();
     
        
        SwingUtilities.invokeLater(() -> {
            Login login = new Login();
            login.setSize(580, 510);
            login.setLocationRelativeTo(null);
            login.setVisible(true);
        });

        Reproductor repro = new Reproductor();

        // Crear listas de canciones
        List<String> cancionesRosalia = List.of(
            "C:\\Users\\" + user + "\\Music\\CUYOfy\\Rosalía\\DESPECHÁ.wav",
            "C:\\Users\\" + user + "\\Music\\CUYOfy\\Rosalía\\Con-Altura.wav",
            "C:\\Users\\" + user + "\\Music\\CUYOfy\\Rosalía\\SAOKO.wav"
        );
        List<String> cancionesAbelPintos = List.of(
            "C:\\Users\\" + user + "\\Music\\CUYOfy\\Abel Pintos\\De Solo Vivir.wav",
            "C:\\Users\\" + user + "\\Music\\CUYOfy\\Abel Pintos\\La Llave.wav",
            "C:\\Users\\" + user + "\\Music\\CUYOfy\\Abel Pintos\\Sin Principio Ni Final.wav"
        );
        List<String> cancionesFitoPaez = List.of(
            "C:\\Users\\" + user + "\\Music\\CUYOfy\\Fito Paez\\circo beat.wav",
            "C:\\Users\\" + user + "\\Music\\CUYOfy\\Fito Paez\\el amor despues del amor.wav",
            "C:\\Users\\" + user + "\\Music\\CUYOfy\\Fito Paez\\mariposa tecknicolor.wav"
        );
        List<String> cancionesACDC = List.of(
            "C:\\Users\\" + user + "\\Music\\CUYOfy\\ACDC\\Back In Black.wav",
            "C:\\Users\\" + user + "\\Music\\CUYOfy\\ACDC\\Thunderstruck.wav",
            "C:\\Users\\" + user + "\\Music\\CUYOfy\\ACDC\\You Shook Me All Night Long.wav"
        );
        List<String> cancionesQueen = List.of(
            "C:\\Users\\" + user + "\\Music\\CUYOfy\\Queen\\Bohemian Rhapsody.wav",
            "C:\\Users\\" + user + "\\Music\\CUYOfy\\Queen\\Crazy Little Thing Called Love.wav",
            "C:\\Users\\" + user + "\\Music\\CUYOfy\\Queen\\Dont Stop Me Now.wav"
        );

        // Asignar canciones a artistas
        cargarCanciones(rosalia, cancionesRosalia, repro);
        cargarCanciones(abelPintos, cancionesAbelPintos, repro);
        cargarCanciones(fitoPaez, cancionesFitoPaez, repro);
        cargarCanciones(acdc, cancionesACDC, repro);
        cargarCanciones(queen, cancionesQueen, repro);
        
        
    //eliminarTodosUsuarios();
    
    }
    
    private static void cargarCanciones(Artista artista, List<String> rutas, Reproductor repro) {
        //Date fecha, String nombre, String descripcion, List<Cancion> listaCanciones
        Album album = new Album(new Date(),  "Album de " + artista.getNombre(), artista.getGeneroM(), new ArrayList<>());
        for (String ruta : rutas) {
            long duracion = repro.getDuracion(ruta);
            String nombre = obtenerNombreDeArchivo(ruta);
            Cancion cancion = new Cancion(nombre, duracion, artista.getNombre());
            album.addCancion(cancion);
            DataBase.guardarCancion(nombre, duracion, artista.getNombre(), album.getNombre());
            listaCancionesGlobal.add(cancion);
            cancionesPorGenero
                .computeIfAbsent(artista.getGeneroM(), k -> new ArrayList<>())
                .add(cancion);
            
        
        }
        artista.listaAlbum.add(album);
    }
       
    // Método para extraer el nombre del archivo sin la extensión
    private static String obtenerNombreDeArchivo(String ruta) {
        return ruta.substring(ruta.lastIndexOf("\\") + 1, ruta.lastIndexOf("."));
    }
   
}


