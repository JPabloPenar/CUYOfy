package ProyectoIntegrador;


import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import java.io.File;
import java.io.IOException;
import java.util.List;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.FloatControl;
import javax.sound.sampled.LineEvent;

public class Reproductor {
    private List<Cancion> playlist;
    private int currentSongIndex = 0;
    
    private Clip audioClip;
    private boolean isPlaying = false;
    private long pausePosition = 0;
    private Cancion currentCancion;
    private boolean isPaused= false;

    public boolean isIsPaused() {
        return isPaused;
    }
    
    
    public Cancion getCurrentCancion() {
        return currentCancion;
    }
    
    public synchronized void play(Cancion cancion) {
        if (isPlaying) {
            System.out.println("Audio is already playing");
            return;
        }
        if (!cancion.equals(currentCancion)) {
            currentCancion = cancion;  // Almacena la nueva ruta del archivo
            pausePosition = 0;  // Reinicia la posición de pausa
        }
        
        new Thread(() -> {
            try {
                // Abre un flujo de entrada de audio desde el archivo
                AudioInputStream audioStream = AudioSystem.getAudioInputStream(new File(cancion.getPath()));
                audioClip = AudioSystem.getClip();
                audioClip.open(audioStream);
                setVolume(80);
                audioClip.setMicrosecondPosition(pausePosition);
                audioClip.start();
                isPlaying = true;
                isPaused = false;
                // Mantiene el hilo en ejecución hasta que el audio termine de reproducirse
                audioClip.addLineListener(event -> {
                    if (event.getType() == javax.sound.sampled.LineEvent.Type.STOP) {
                        isPlaying = false;
                        isPaused= true;
                        audioClip.close();
                    }
                });

            } catch (UnsupportedAudioFileException | IOException | LineUnavailableException e) {
                e.printStackTrace();
                isPlaying = false; // Asegura que isPlaying se establece en false si ocurre un error
            }
        }).start();
    }

    public synchronized void stop() {
        if (audioClip != null && audioClip.isRunning()) {
            audioClip.stop();
            isPlaying = false;
            isPaused= true;
        }
    }
    
    public synchronized void pause() {
        if (audioClip != null && audioClip.isRunning()) {
            pausePosition = audioClip.getMicrosecondPosition();
            
            audioClip.stop();
            isPlaying = false;
            isPaused= true;
        }
    }
      public synchronized void resume() {
          
        if (audioClip != null && !isPlaying) {
            new Thread(() -> {
                try {
                    // Abre un flujo de entrada de audio desde el archivo
                    AudioInputStream audioStream = AudioSystem.getAudioInputStream(new File(currentCancion.getPath()));
                    audioClip.open(audioStream);
                    audioClip.setMicrosecondPosition(pausePosition); // Comienza desde la posición pausada
                    audioClip.start();
                    isPlaying = true;
                    isPaused= false;
                    // Mantiene el hilo en ejecución hasta que el audio termine de reproducirse
                    audioClip.addLineListener(event -> {
                        if (event.getType() == javax.sound.sampled.LineEvent.Type.STOP && isPlaying) {
                            isPlaying = false;
                            audioClip.close();
                        }
                    });

                } catch (UnsupportedAudioFileException | IOException | LineUnavailableException e) {
                    e.printStackTrace();
                    isPlaying = false; // Asegura que isPlaying se establece en false si ocurre un error
                }
            }).start();
        }
    }

        
    public boolean isPlaying() {
        return isPlaying;
    }
    public boolean isPaused() {
        return isPlaying;
    }

    public void setVolume(int volume) {
        if (audioClip != null && audioClip.isOpen()) {
            FloatControl volumeControl = (FloatControl) audioClip.getControl(FloatControl.Type.MASTER_GAIN);
            float min = volumeControl.getMinimum();
            float max = volumeControl.getMaximum();
            float volumeRange = max - min;
            float volumeLevel = min + (volumeRange * (volume / 100.0f));
            volumeControl.setValue(volumeLevel);
        }
    }

    public long getDuracion(String audioFilePath) {
        try (AudioInputStream audioInputStream = AudioSystem.getAudioInputStream(new File(audioFilePath))) {
            AudioFormat format = audioInputStream.getFormat();
            long audioFileLength = new File(audioFilePath).length();
            int frameSize = format.getFrameSize();
            float frameRate = format.getFrameRate();
            return (long) ((audioFileLength / (frameSize * frameRate)) * 1000);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }
    public long getCurrentPosition() {
    if (audioClip != null && audioClip.isRunning()) {
        return audioClip.getMicrosecondPosition() / 1000; // Devuelve la posición en milisegundos
        
    }
    return 0;
}
    public void reproducirPlaylist(List<Cancion> canciones) {
        this.playlist = canciones;
        currentSongIndex = 0;
        reproducirCancion();
    }

    private void reproducirCancion() {
        if (currentSongIndex < playlist.size()) {
            Cancion cancion = playlist.get(currentSongIndex);
            String ruta = cancion.getPath(); // Obtén la ruta desde la canción
            try {
                AudioInputStream audioStream = AudioSystem.getAudioInputStream(new File(ruta));
                audioClip = AudioSystem.getClip();
                audioClip.open(audioStream);
                audioClip.start();
                
                audioClip.addLineListener(event -> {
                    if (event.getType() == LineEvent.Type.STOP) {
                        audioClip.close();
                        currentSongIndex++;
                        reproducirCancion(); // Reproduce la siguiente canción
                    }
                });
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public void detener() {
        if (audioClip != null && audioClip.isRunning()) {
            audioClip.stop();
            audioClip.close();
        }
    }


}
