
package ProyectoIntegrador;


import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;
import javax.swing.JProgressBar;
import javax.swing.Timer;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;


public class PanelInicio extends javax.swing.JPanel {
    
    private InterfazMain mainFrame;
    Reproductor repro = new Reproductor();
    private JProgressBar progressBar;
    private Timer timer;
    public static MeGusta mg = new MeGusta();
    
       
    public PanelInicio(InterfazMain mainFrame) {
        this.mainFrame = mainFrame;
        setLayout(null);
        initComponents();
        initializeProgressBar();
        configureSlider();
        startProgressBarUpdate();
        
        progressBar = new JProgressBar(0, 100);
        progressBar.setStringPainted(true);
    }
    private void initializeProgressBar() {
            // Crear la instancia de JProgressBar
            ProgressBar.setMinimum(0);
            ProgressBar.setMaximum(100);
            ProgressBar.setValue(0); // Valor inicial de la barra de progreso

            // Añadir la barra de progreso al panel
            jPanel1.add(ProgressBar);
        }
     private void startProgressBarUpdate() {
            // Configurar el Timer para actualizar la barra de progreso cada 500 ms (0.5 segundos)
            timer = new Timer(500, new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    // Verificar si la canción se está reproduciendo
                    if (repro.isPlaying() && repro.getCurrentCancion().getPath() != null) {
                        // Obtener la duración total de la canción y la posición actual en milisegundos
                        long duracionTotal = repro.getCurrentCancion().getDuracion();
                        long posicionActual = repro.getCurrentPosition();
                        
                        Tiempo.setText(formatTiempo(posicionActual)+ "/" +formatTiempo(duracionTotal));
                        
                        if (duracionTotal > 0) {
                            // Calcular el porcentaje de progreso
                            int progreso = (int) ((posicionActual * 100) / duracionTotal);
                            ProgressBar.setValue(progreso);
                        }
                    } else {
                        // Detener el Timer si la canción no está en reproducción
                        timer.stop();
                        ProgressBar.setValue(0); // Reiniciar la barra de progreso
                    }
                }
            });

            // Iniciar el Timer
            timer.start();
        }
    private String formatTiempo(long tiempoEnMilisegundos) {
    long segundos = (tiempoEnMilisegundos / 1000) % 60;
    long minutos = (tiempoEnMilisegundos / (1000 * 60)) % 60;
   
    
    // Formatear el tiempo como HH:MM:SS
    return String.format("%02d:%02d", minutos, segundos);
}
    private void configureSlider() {
        // Configuración del JSlider
        jSlider1.setMinimum(40);
        jSlider1.setMaximum(90);
        jSlider1.setValue(80); // Valor inicial del volumen al 50%

        // Agregar ChangeListener
        jSlider1.addChangeListener(new ChangeListener() {
            @Override
            public void stateChanged(ChangeEvent e) {
                int volume = jSlider1.getValue();
                repro.setVolume(volume);
            }
        });
    }     
    

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        NombreC1 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        jPanel1 = new javax.swing.JPanel();
        jSlider1 = new javax.swing.JSlider();
        NombreC = new javax.swing.JLabel();
        STOP = new javax.swing.JButton();
        ProgressBar = new javax.swing.JProgressBar();
        PauseB = new javax.swing.JButton();
        NombreA = new javax.swing.JLabel();
        Tiempo = new javax.swing.JLabel();
        meGustaBoton = new javax.swing.JButton();
        CantidadMeGusta = new javax.swing.JLabel();
        CantidadRepro = new javax.swing.JLabel();
        ArtistasText = new javax.swing.JLabel();
        RosalíaBoton = new javax.swing.JButton();
        FitoPaezBoton = new javax.swing.JButton();
        AbelPintosBoton = new javax.swing.JButton();
        ACDCBoton = new javax.swing.JButton();
        QueenBoton = new javax.swing.JButton();
        ListasText = new javax.swing.JLabel();
        MeGustaBoton = new javax.swing.JButton();
        PlayListBoton = new javax.swing.JButton();

        NombreC1.setFont(new java.awt.Font("Lucida Fax", 3, 14)); // NOI18N
        NombreC1.setForeground(new java.awt.Color(255, 255, 255));
        NombreC1.setText("--");

        setBackground(new java.awt.Color(0, 51, 51));
        setFont(new java.awt.Font("Lucida Fax", 0, 12)); // NOI18N

        jLabel1.setFont(new java.awt.Font("Lucida Fax", 3, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Inicio");

        jPanel1.setBackground(new java.awt.Color(0, 153, 153));

        jSlider1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        NombreC.setFont(new java.awt.Font("Lucida Fax", 3, 14)); // NOI18N
        NombreC.setForeground(new java.awt.Color(255, 255, 255));
        NombreC.setText("--");

        STOP.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        STOP.setText("■");
        STOP.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                STOPMouseClicked(evt);
            }
        });
        STOP.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                STOPActionPerformed(evt);
            }
        });

        PauseB.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        PauseB.setText(" | | ");
        PauseB.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                PauseBMouseClicked(evt);
            }
        });
        PauseB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PauseBActionPerformed(evt);
            }
        });

        NombreA.setFont(new java.awt.Font("Lucida Fax", 1, 12)); // NOI18N
        NombreA.setForeground(new java.awt.Color(255, 255, 255));
        NombreA.setText("--");

        Tiempo.setFont(new java.awt.Font("Lucida Fax", 3, 12)); // NOI18N
        Tiempo.setForeground(new java.awt.Color(255, 255, 255));
        Tiempo.setText("0:00/0:00");

        meGustaBoton.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        meGustaBoton.setText("♥");
        meGustaBoton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                meGustaBotonMouseClicked(evt);
            }
        });
        meGustaBoton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                meGustaBotonActionPerformed(evt);
            }
        });

        CantidadMeGusta.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        CantidadMeGusta.setForeground(new java.awt.Color(255, 255, 255));
        CantidadMeGusta.setText("--♥");

        CantidadRepro.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        CantidadRepro.setForeground(new java.awt.Color(255, 255, 255));
        CantidadRepro.setText("--►");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(STOP)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(PauseB)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(ProgressBar, javax.swing.GroupLayout.PREFERRED_SIZE, 311, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(Tiempo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(102, 102, 102))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(NombreA, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(CantidadMeGusta, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(67, 67, 67)
                                .addComponent(CantidadRepro, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(NombreC, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(meGustaBoton)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jSlider1, javax.swing.GroupLayout.PREFERRED_SIZE, 153, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(156, 156, 156))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(27, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(STOP)
                            .addComponent(PauseB))
                        .addComponent(Tiempo))
                    .addComponent(ProgressBar, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(7, 7, 7)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(NombreC)
                    .addComponent(meGustaBoton)
                    .addComponent(jSlider1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(NombreA)
                    .addComponent(CantidadMeGusta)
                    .addComponent(CantidadRepro))
                .addGap(42, 42, 42))
        );

        ArtistasText.setFont(new java.awt.Font("Lucida Fax", 3, 18)); // NOI18N
        ArtistasText.setForeground(new java.awt.Color(255, 255, 255));
        ArtistasText.setText("Artistas:");

        RosalíaBoton.setBackground(new java.awt.Color(204, 255, 255));
        RosalíaBoton.setText("Rosalía");
        RosalíaBoton.setPreferredSize(new java.awt.Dimension(90, 90));
        RosalíaBoton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                RosalíaBotonMouseClicked(evt);
            }
        });
        RosalíaBoton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RosalíaBotonActionPerformed(evt);
            }
        });

        FitoPaezBoton.setBackground(new java.awt.Color(204, 255, 255));
        FitoPaezBoton.setText("Fito Paez");
        FitoPaezBoton.setPreferredSize(new java.awt.Dimension(90, 90));
        FitoPaezBoton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                FitoPaezBotonMouseClicked(evt);
            }
        });
        FitoPaezBoton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                FitoPaezBotonActionPerformed(evt);
            }
        });

        AbelPintosBoton.setBackground(new java.awt.Color(204, 255, 255));
        AbelPintosBoton.setText("Abel Pintos");
        AbelPintosBoton.setPreferredSize(new java.awt.Dimension(90, 90));
        AbelPintosBoton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                AbelPintosBotonMouseClicked(evt);
            }
        });
        AbelPintosBoton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AbelPintosBotonActionPerformed(evt);
            }
        });

        ACDCBoton.setBackground(new java.awt.Color(204, 255, 255));
        ACDCBoton.setText("ACDC");
        ACDCBoton.setPreferredSize(new java.awt.Dimension(90, 90));
        ACDCBoton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ACDCBotonMouseClicked(evt);
            }
        });
        ACDCBoton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ACDCBotonActionPerformed(evt);
            }
        });

        QueenBoton.setBackground(new java.awt.Color(204, 255, 255));
        QueenBoton.setText("Queen");
        QueenBoton.setPreferredSize(new java.awt.Dimension(90, 90));
        QueenBoton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                QueenBotonMouseClicked(evt);
            }
        });
        QueenBoton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                QueenBotonActionPerformed(evt);
            }
        });

        ListasText.setFont(new java.awt.Font("Lucida Fax", 3, 18)); // NOI18N
        ListasText.setForeground(new java.awt.Color(255, 255, 255));
        ListasText.setText("Listas");

        MeGustaBoton.setBackground(new java.awt.Color(204, 255, 255));
        MeGustaBoton.setText("MeGusta");
        MeGustaBoton.setPreferredSize(new java.awt.Dimension(90, 90));
        MeGustaBoton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                MeGustaBotonMouseClicked(evt);
            }
        });
        MeGustaBoton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MeGustaBotonActionPerformed(evt);
            }
        });

        PlayListBoton.setBackground(new java.awt.Color(204, 255, 255));
        PlayListBoton.setText("PlayList");
        PlayListBoton.setPreferredSize(new java.awt.Dimension(90, 90));
        PlayListBoton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PlayListBotonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(ListasText)
                            .addComponent(ArtistasText))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jSeparator1)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(RosalíaBoton, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(AbelPintosBoton, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(FitoPaezBoton, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(ACDCBoton, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(QueenBoton, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(MeGustaBoton, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(43, 43, 43)
                                        .addComponent(PlayListBoton, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addContainerGap())))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(ArtistasText)
                .addGap(24, 24, 24)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(RosalíaBoton, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(FitoPaezBoton, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(AbelPintosBoton, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(ACDCBoton, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(QueenBoton, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(ListasText)
                .addGap(37, 37, 37)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(MeGustaBoton, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(PlayListBoton, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
    }// </editor-fold>//GEN-END:initComponents

     private void reproducirCancion(Artista artista) {
        repro.stop();
        if (artista.listaAlbum.isEmpty() || artista.listaAlbum.get(0).canciones.isEmpty()) {
            System.out.println("El artista no tiene canciones disponibles.");
            return;
        }
        Album album = artista.listaAlbum.get(0);
        Cancion cancion = album.canciones.get(new Random().nextInt(album.canciones.size()));
        repro.play(cancion);
        NombreC.setText(cancion.getNombre());
        NombreA.setText(cancion.getArtista());
        PauseB.setText("| |"); 
        startProgressBarUpdate();
       
        DataBase.agregarReproduccion( Login.nombreUsuario, repro.getCurrentCancion().getNombre());
        CantidadMeGusta.setText(String.valueOf(DataBase.contarMeGustas(repro.getCurrentCancion().getNombre())) + "♥");
        CantidadRepro.setText(String.valueOf(DataBase.contarReproducciones(repro.getCurrentCancion().getNombre())) + "►");
        
        if(mg.isLiked(repro.getCurrentCancion())){
            meGustaBoton.setText("X");
            
        } else {
            
             meGustaBoton.setText("♥");
           
        
        }
     }
    
    private void RosalíaBotonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RosalíaBotonActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_RosalíaBotonActionPerformed

    private void FitoPaezBotonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_FitoPaezBotonActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_FitoPaezBotonActionPerformed

    private void AbelPintosBotonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AbelPintosBotonActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_AbelPintosBotonActionPerformed

    private void ACDCBotonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ACDCBotonActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ACDCBotonActionPerformed

    private void QueenBotonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_QueenBotonActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_QueenBotonActionPerformed

    private void MeGustaBotonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MeGustaBotonActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_MeGustaBotonActionPerformed

    private void PlayListBotonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PlayListBotonActionPerformed
        repro.stop();
        mainFrame.ShowPanel(new PanelPlayList()); // Cambia al PanelPlayList
    }//GEN-LAST:event_PlayListBotonActionPerformed

    private void RosalíaBotonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_RosalíaBotonMouseClicked
         reproducirCancion(ProyectoIntegrador1.rosalia);
    }//GEN-LAST:event_RosalíaBotonMouseClicked

    private void AbelPintosBotonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_AbelPintosBotonMouseClicked
        reproducirCancion(ProyectoIntegrador1.abelPintos); 
    }//GEN-LAST:event_AbelPintosBotonMouseClicked

    private void FitoPaezBotonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_FitoPaezBotonMouseClicked
        reproducirCancion(ProyectoIntegrador1.fitoPaez);  
    }//GEN-LAST:event_FitoPaezBotonMouseClicked

    private void ACDCBotonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ACDCBotonMouseClicked
        reproducirCancion(ProyectoIntegrador1.acdc);  
    }//GEN-LAST:event_ACDCBotonMouseClicked

    private void QueenBotonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_QueenBotonMouseClicked
        reproducirCancion(ProyectoIntegrador1.queen); 
    }//GEN-LAST:event_QueenBotonMouseClicked

    private void STOPActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_STOPActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_STOPActionPerformed

    private void STOPMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_STOPMouseClicked
        repro.stop();
        NombreC.setText("--");
        NombreA.setText("--");
        PauseB.setText("►");  // Volver el botón de pausa a "Reanudar"
        timer.stop(); 
    }//GEN-LAST:event_STOPMouseClicked

    private void PauseBMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PauseBMouseClicked
           if (repro.isPaused()) {
            repro.pause();
            timer.stop();
            PauseB.setText("►");
    } else {
            repro.resume();  
            timer.start();   
            PauseB.setText("| |");  
    }
    }//GEN-LAST:event_PauseBMouseClicked

    private void PauseBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PauseBActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_PauseBActionPerformed

    private void meGustaBotonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_meGustaBotonMouseClicked
        Cancion actual= repro.getCurrentCancion();
        
        if(mg.isLiked(actual)){
            meGustaBoton.setText("♥");
            mg.quitarMusica(actual);
            DataBase.eliminarMeGusta(Login.nombreUsuario, actual.getNombre());
        } else {
            
            meGustaBoton.setText("X");
            mg.addCancion(repro.getCurrentCancion());
            DataBase.agregarMeGusta(Login.nombreUsuario, actual.getNombre());
        }
         CantidadMeGusta.setText(String.valueOf(DataBase.contarMeGustas(repro.getCurrentCancion().getNombre())) + "♥");
    }//GEN-LAST:event_meGustaBotonMouseClicked

    private void meGustaBotonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_meGustaBotonActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_meGustaBotonActionPerformed

    private void MeGustaBotonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_MeGustaBotonMouseClicked
            repro.stop();
           
            mainFrame.ShowPanel(new PanelMeGusta());
            
    }//GEN-LAST:event_MeGustaBotonMouseClicked
    
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton ACDCBoton;
    private javax.swing.JButton AbelPintosBoton;
    private javax.swing.JLabel ArtistasText;
    private javax.swing.JLabel CantidadMeGusta;
    private javax.swing.JLabel CantidadRepro;
    private javax.swing.JButton FitoPaezBoton;
    private javax.swing.JLabel ListasText;
    private javax.swing.JButton MeGustaBoton;
    private javax.swing.JLabel NombreA;
    private javax.swing.JLabel NombreC;
    private javax.swing.JLabel NombreC1;
    private javax.swing.JButton PauseB;
    private javax.swing.JButton PlayListBoton;
    private javax.swing.JProgressBar ProgressBar;
    private javax.swing.JButton QueenBoton;
    private javax.swing.JButton RosalíaBoton;
    private javax.swing.JButton STOP;
    private javax.swing.JLabel Tiempo;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSlider jSlider1;
    private javax.swing.JButton meGustaBoton;
    // End of variables declaration//GEN-END:variables
}
