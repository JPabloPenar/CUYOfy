
package ProyectoIntegrador;

import java.awt.Color;

  
public class Register extends javax.swing.JFrame {
    ///Atributos para indicar la Posicion del mouse

      int xMouse,yMouse;
      private String nombreUsuario;
      private String contraseña;
      private int verificacionInicio;
      private DataBase db;
      public Register() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        Registro = new javax.swing.JLabel();
        TxtUsuario = new javax.swing.JLabel();
        Txtcontraseña = new javax.swing.JLabel();
        TxtFieldUsuario = new javax.swing.JTextField();
        RegisterButton1 = new javax.swing.JToggleButton();
        barraSup = new javax.swing.JPanel();
        exitButton = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        TxtFieldContraseña = new javax.swing.JPasswordField();
        NoValido = new javax.swing.JLabel();
        usuarioNV = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(102, 153, 255));

        Registro.setFont(new java.awt.Font("Lucida Fax", 3, 18)); // NOI18N
        Registro.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Registro.setText("Registrarse");

        TxtUsuario.setText("Usuario");

        Txtcontraseña.setText("Contraseña");

        TxtFieldUsuario.setText("Ingrese Usuario");
        TxtFieldUsuario.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                TxtFieldUsuarioMousePressed(evt);
            }
        });

        RegisterButton1.setBackground(new java.awt.Color(102, 153, 255));
        RegisterButton1.setText("Registrarse");
        RegisterButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RegisterButton1ActionPerformed(evt);
            }
        });

        barraSup.setBackground(new java.awt.Color(0, 0, 255));
        barraSup.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                barraSupMouseDragged(evt);
            }
        });
        barraSup.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                barraSupMousePressed(evt);
            }
        });

        exitButton.setBackground(new java.awt.Color(0, 0, 255));
        exitButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        exitButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                exitButtonMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                exitButtonMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                exitButtonMouseExited(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Dialog", 0, 24)); // NOI18N
        jLabel1.setText("x");

        javax.swing.GroupLayout exitButtonLayout = new javax.swing.GroupLayout(exitButton);
        exitButton.setLayout(exitButtonLayout);
        exitButtonLayout.setHorizontalGroup(
            exitButtonLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(exitButtonLayout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addComponent(jLabel1)
                .addContainerGap(30, Short.MAX_VALUE))
        );
        exitButtonLayout.setVerticalGroup(
            exitButtonLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(exitButtonLayout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jLabel1)
                .addContainerGap(21, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout barraSupLayout = new javax.swing.GroupLayout(barraSup);
        barraSup.setLayout(barraSupLayout);
        barraSupLayout.setHorizontalGroup(
            barraSupLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(barraSupLayout.createSequentialGroup()
                .addComponent(exitButton, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        barraSupLayout.setVerticalGroup(
            barraSupLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(exitButton, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        TxtFieldContraseña.setText("**********");
        TxtFieldContraseña.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                TxtFieldContraseñaMousePressed(evt);
            }
        });

        NoValido.setForeground(new java.awt.Color(255, 0, 0));

        usuarioNV.setForeground(new java.awt.Color(255, 0, 0));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(Registro, javax.swing.GroupLayout.DEFAULT_SIZE, 558, Short.MAX_VALUE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(Txtcontraseña)
                            .addComponent(TxtUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(TxtFieldUsuario, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 411, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(NoValido, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(TxtFieldContraseña, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 411, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(usuarioNV, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 353, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap())
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(31, 31, 31)
                .addComponent(RegisterButton1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addComponent(barraSup, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(barraSup, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(79, 79, 79)
                .addComponent(Registro, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(56, 56, 56)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(TxtFieldUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(TxtUsuario))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(usuarioNV)
                .addGap(34, 34, 34)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Txtcontraseña)
                    .addComponent(TxtFieldContraseña, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(NoValido)
                .addGap(34, 34, 34)
                .addComponent(RegisterButton1)
                .addContainerGap(82, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    
    private void RegisterButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RegisterButton1ActionPerformed
        verificacionInicio = 2;
    nombreUsuario = TxtFieldUsuario.getText().trim();
    contraseña = new String(TxtFieldContraseña.getPassword()).trim();

    // Validar nombre de usuario y contraseña
    if (nombreUsuario.isEmpty() || "Ingrese Usuario".equals(nombreUsuario) || db.existeUsuario(nombreUsuario)) {
        usuarioNV.setText("Nombre de usuario no válido");
        verificacionInicio--;
    }
    if (contraseña.length() < 5) {
        NoValido.setText("Contraseña demasiado corta");
        verificacionInicio--;
    }
    if (verificacionInicio == 2) {
        Cuenta nuevaCuenta = new Cuenta(nombreUsuario); 
        db.guardarUsuarioEnBaseDeDatos(nuevaCuenta.getNombre(), contraseña);
        this.setVisible(false);
    }
        
    }//GEN-LAST:event_RegisterButton1ActionPerformed

    ///Barra superior  y boton de cierre de ventana-----------------------------------------------------------
    
    private void barraSupMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_barraSupMousePressed
           // Evento de cuando el mouse se presiona
        xMouse = evt.getX();
        yMouse = evt.getY();
        
    }//GEN-LAST:event_barraSupMousePressed

    private void barraSupMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_barraSupMouseDragged
       
        //debemos considerar la posicion del mouse en la pantalla
        int x = evt.getXOnScreen();
        int y = evt.getYOnScreen();

     // Establecer lal locaclizacion de la ventana en el eje seleccionado
        this.setLocation(x - xMouse,y -  yMouse);
        
        
    }//GEN-LAST:event_barraSupMouseDragged

    private void exitButtonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_exitButtonMouseClicked
      // Evemtp click para cerrar ventana
        System.exit(0);
        
    }//GEN-LAST:event_exitButtonMouseClicked

    private void exitButtonMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_exitButtonMouseEntered
        
          // Evento cuando el mouse entre en el panel
        exitButton.setBackground(Color.RED);
        //cambio de color 
        exitButton.setForeground(Color.white);
        
    }//GEN-LAST:event_exitButtonMouseEntered

    private void exitButtonMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_exitButtonMouseExited
      
        // Evento cunado el mouse sale del panel 
        exitButton.setBackground(Color.BLUE);
        exitButton.setForeground(Color.black);
        
    }//GEN-LAST:event_exitButtonMouseExited
    ////---------------------------------------------------------------------------
    
    /// PLACEHOLDER DEL REGRISTRO -------------------------------------------------
    private void TxtFieldUsuarioMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TxtFieldUsuarioMousePressed

         if (TxtFieldUsuario.getText().equals("Ingrese Usuario")) {
            TxtFieldUsuario.setText("");
            TxtFieldUsuario.setForeground(Color.black);
        }
        if (String.valueOf(TxtFieldContraseña.getPassword()).isEmpty()) {
            TxtFieldContraseña.setText("**********");
            TxtFieldContraseña.setForeground(Color.gray);
        }
        
        
    }//GEN-LAST:event_TxtFieldUsuarioMousePressed

    private void TxtFieldContraseñaMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TxtFieldContraseñaMousePressed
        // TODO add your handling code here:
        if (String.valueOf(TxtFieldContraseña.getPassword()).equals("**********")) {
            TxtFieldContraseña.setText("");
            TxtFieldContraseña.setForeground(Color.black);
        }
        if (TxtFieldUsuario.getText().isEmpty()) {
            TxtFieldUsuario.setText("Ingrese Usuario");
            TxtFieldUsuario.setForeground(Color.gray);
        }
    }//GEN-LAST:event_TxtFieldContraseñaMousePressed
//-------------------------------------------------------------------------------------------
  


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel NoValido;
    private javax.swing.JToggleButton RegisterButton1;
    private javax.swing.JLabel Registro;
    private javax.swing.JPasswordField TxtFieldContraseña;
    private javax.swing.JTextField TxtFieldUsuario;
    private javax.swing.JLabel TxtUsuario;
    private javax.swing.JLabel Txtcontraseña;
    private javax.swing.JPanel barraSup;
    private javax.swing.JPanel exitButton;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel usuarioNV;
    // End of variables declaration//GEN-END:variables
}
