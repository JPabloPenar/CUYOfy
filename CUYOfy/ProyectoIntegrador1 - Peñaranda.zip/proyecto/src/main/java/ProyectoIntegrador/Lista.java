package ProyectoIntegrador;
import java.util.ArrayList;
import java.util.List;

public class Lista {
    
    int cantidadCanciones;
    ArrayList<Cancion> canciones= new ArrayList<>();
    private Artista artista;
    
    public Lista() {
        super(); 
        this.cantidadCanciones = 0;
    }

    public int getCantidadCanciones() {
        return cantidadCanciones;
    }

    public void addCancion(Cancion cancion){
        canciones.add(cancion);
        cantidadCanciones++;
    }
    
    public void quitarMusica(Cancion cancion) {
        canciones.remove(cancion);
        cantidadCanciones--;
    }
     
public static String mostrar(List<String> canciones) { //ES OBLIGATORIO USAR HTML PARA HACER UN SALTO DE LÍNEA AL USAR JLABEL
    StringBuilder lista = new StringBuilder();
    lista.append("<html>"); // Iniciar HTML

    for (int i = 0; i < canciones.size(); i++) {
        lista.append(canciones.get(i)); // Añadir la canción
        if (i < canciones.size() - 1) {
            lista.append("<br/>"); // Añadir salto de línea
        }
    }
    lista.append("</html>"); // Cerrar HTML

    return lista.toString();
}
   public List<String> obtenerCancionesPorGenero(String genero) {
    List<Cancion> canciones = ProyectoIntegrador1.cancionesPorGenero.getOrDefault(genero, new ArrayList<>());
    List<String> nombresCanciones = new ArrayList<>();
    
    for (Cancion cancion : canciones) {
        nombresCanciones.add(cancion.getArtista()+ "/" +cancion.getNombre());
    }
    return nombresCanciones;
}


}
     