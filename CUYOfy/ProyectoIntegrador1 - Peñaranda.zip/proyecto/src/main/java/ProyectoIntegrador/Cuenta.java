package ProyectoIntegrador;
public class Cuenta {
    
    public String nombreC;

    public Cuenta(String nombreC) {
        super();
        this.nombreC = nombreC;
    }

    public String getNombre() {
        return nombreC;
    }    
    
}