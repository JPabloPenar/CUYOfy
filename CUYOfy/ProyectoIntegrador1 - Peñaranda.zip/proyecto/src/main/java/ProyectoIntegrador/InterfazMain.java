
package ProyectoIntegrador;

import javax.swing.JPanel;


public class InterfazMain extends javax.swing.JFrame {
    
    Reproductor repro= new Reproductor();
    public InterfazMain() {
        initComponents();
        
        
        PanelInicio panelInicio = new PanelInicio(this);
        panelInicio.setSize(542, 500);
        panelInicio.setLocation(0, 0);
        
        interfaz.removeAll();
        interfaz.add(panelInicio);
        interfaz.revalidate();
        interfaz.repaint();
    }

    void ShowPanel(JPanel p){
        
        p.setSize(542, 500);
        p.setLocation(0, 0);
        
        interfaz.removeAll();
        interfaz.add(p);
        interfaz.revalidate();
        interfaz.repaint();
        
    }
 
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        Titulo = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        BotonInicio = new javax.swing.JButton();
        BotonRock = new javax.swing.JButton();
        BotonCumbia = new javax.swing.JButton();
        BotonFolklore = new javax.swing.JButton();
        BotonPop = new javax.swing.JButton();
        BotonReggaeton = new javax.swing.JButton();
        Generos = new javax.swing.JLabel();
        interfaz = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(0, 102, 102));

        Titulo.setFont(new java.awt.Font("Lucida Fax", 3, 24)); // NOI18N
        Titulo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Titulo.setText("cuyofy");

        BotonInicio.setBackground(new java.awt.Color(0, 102, 102));
        BotonInicio.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        BotonInicio.setText("Inicio");
        BotonInicio.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        BotonInicio.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        BotonInicio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotonInicioActionPerformed(evt);
            }
        });

        BotonRock.setBackground(new java.awt.Color(0, 102, 102));
        BotonRock.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        BotonRock.setText("Rock Nacional");
        BotonRock.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        BotonRock.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        BotonRock.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotonRockActionPerformed(evt);
            }
        });

        BotonCumbia.setBackground(new java.awt.Color(0, 102, 102));
        BotonCumbia.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        BotonCumbia.setText("cumbia");
        BotonCumbia.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        BotonCumbia.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        BotonCumbia.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotonCumbiaActionPerformed(evt);
            }
        });

        BotonFolklore.setBackground(new java.awt.Color(0, 102, 102));
        BotonFolklore.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        BotonFolklore.setText("Folklore");
        BotonFolklore.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        BotonFolklore.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        BotonFolklore.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotonFolkloreActionPerformed(evt);
            }
        });

        BotonPop.setBackground(new java.awt.Color(0, 102, 102));
        BotonPop.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        BotonPop.setText("Pop");
        BotonPop.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        BotonPop.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        BotonPop.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotonPopActionPerformed(evt);
            }
        });

        BotonReggaeton.setBackground(new java.awt.Color(0, 102, 102));
        BotonReggaeton.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        BotonReggaeton.setText("Reggaeton");
        BotonReggaeton.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        BotonReggaeton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        BotonReggaeton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotonReggaetonActionPerformed(evt);
            }
        });

        Generos.setFont(new java.awt.Font("Lucida Fax", 3, 12)); // NOI18N
        Generos.setText("Generos Musicales");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(BotonInicio, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(BotonPop, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(BotonFolklore, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(BotonCumbia, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(BotonRock, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(BotonReggaeton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(Titulo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(36, 36, 36)
                        .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(Generos, javax.swing.GroupLayout.DEFAULT_SIZE, 140, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(40, 40, 40)
                .addComponent(Titulo, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(BotonInicio, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(Generos, javax.swing.GroupLayout.DEFAULT_SIZE, 26, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addComponent(BotonRock, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(BotonCumbia, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(BotonFolklore, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(BotonPop, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(BotonReggaeton, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        interfaz.setBackground(new java.awt.Color(0, 51, 51));

        javax.swing.GroupLayout interfazLayout = new javax.swing.GroupLayout(interfaz);
        interfaz.setLayout(interfazLayout);
        interfazLayout.setHorizontalGroup(
            interfazLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 542, Short.MAX_VALUE)
        );
        interfazLayout.setVerticalGroup(
            interfazLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(interfaz, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(interfaz, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void BotonInicioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotonInicioActionPerformed
        repro.stop();
        PanelInicio panelInicio = new PanelInicio(this);
        ShowPanel(panelInicio);
    }//GEN-LAST:event_BotonInicioActionPerformed

    private void BotonFolkloreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotonFolkloreActionPerformed
        repro.stop();
        PanelFolklore panelFolklore = new PanelFolklore();
        ShowPanel(panelFolklore);
        
    }//GEN-LAST:event_BotonFolkloreActionPerformed

    private void BotonRockActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotonRockActionPerformed
        repro.stop();
        PanelRockNacional panelRockNacional = new PanelRockNacional();
        ShowPanel(panelRockNacional);
    }//GEN-LAST:event_BotonRockActionPerformed

    private void BotonCumbiaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotonCumbiaActionPerformed
        repro.stop();
        PanelCumbia panelCumbia = new PanelCumbia();
        ShowPanel(panelCumbia);
    }//GEN-LAST:event_BotonCumbiaActionPerformed

    private void BotonPopActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotonPopActionPerformed
        repro.stop();
        PanelRock panelRock = new PanelRock();
        ShowPanel(panelRock);
    }//GEN-LAST:event_BotonPopActionPerformed

    private void BotonReggaetonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotonReggaetonActionPerformed
        repro.stop();
        PanelReggaeton panelReggaeton = new PanelReggaeton();
        ShowPanel(panelReggaeton);
    }//GEN-LAST:event_BotonReggaetonActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BotonCumbia;
    private javax.swing.JButton BotonFolklore;
    private javax.swing.JButton BotonInicio;
    private javax.swing.JButton BotonPop;
    private javax.swing.JButton BotonReggaeton;
    private javax.swing.JButton BotonRock;
    private javax.swing.JLabel Generos;
    private javax.swing.JLabel Titulo;
    private javax.swing.JPanel interfaz;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JSeparator jSeparator1;
    // End of variables declaration//GEN-END:variables
}
