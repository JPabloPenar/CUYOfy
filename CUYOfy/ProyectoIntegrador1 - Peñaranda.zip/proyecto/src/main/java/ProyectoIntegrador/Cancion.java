
package ProyectoIntegrador;

public class Cancion {

    private final String nombre;
    private final String path;
    private final String artista;
    private long duracion;
    
    public Cancion(String nombre, long duracion, String artista) {
        this.artista= artista;
        this.nombre = nombre;
        this.duracion = duracion;
        this.path = "C:\\Users\\"+ProyectoIntegrador1.user+"\\Music\\CUYOfy\\"+artista+"\\"+ nombre+ ".wav";
    }

    public String getNombre() {
        return nombre;
    }

    public String getArtista() {
        return artista;
    }

    public long  getDuracion() {
        return duracion;
    }

    public String getPath() {
        return path;
    }


}
    
    
    
    