package ProyectoIntegrador;

public interface Interface {
    void playSong(String songName);
    
}