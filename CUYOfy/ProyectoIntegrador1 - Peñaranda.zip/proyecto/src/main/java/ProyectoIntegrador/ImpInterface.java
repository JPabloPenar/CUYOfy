package ProyectoIntegrador;

public class ImpInterface implements Interface {
    private final Reproductor repro;
    
    public ImpInterface() {
        this.repro = new Reproductor();
        //new DataBase();
    }

     @Override
        public void playSong(String nombreCancion) { //Reproduce una cancion utilzando su nombre en lugar de la clase
        String artistaCancion = DataBase.devolverArtista(nombreCancion);
        long duracionCancion = DataBase.devolverDuracion(nombreCancion);
        Cancion cancion= new Cancion(nombreCancion, duracionCancion, artistaCancion);
        repro.play(cancion);
        repro.stop();
    }    
}
