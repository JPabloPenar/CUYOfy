
package ProyectoIntegrador;

import java.awt.Color;


public class Login extends javax.swing.JFrame {

    ///Atributos para indicar la Posicion del mouse
    
    int xMouse,yMouse;
    public static String nombreUsuario;
    private String contraseña;
    private DataBase db;
    private int verificacion;
    public Login() {
        initComponents();
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        TxtUsuario = new javax.swing.JLabel();
        contraseñaInválida = new javax.swing.JLabel();
        Titulo = new javax.swing.JLabel();
        IniciarSesion = new javax.swing.JButton();
        TxtRegistro = new javax.swing.JLabel();
        Registro = new javax.swing.JToggleButton();
        TxtFieldUsuario = new javax.swing.JTextField();
        barraSup = new javax.swing.JPanel();
        exitButton = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        TxtFieldcontraseña = new javax.swing.JPasswordField();
        noExiste = new javax.swing.JLabel();
        TxtContraseña1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(102, 153, 255));

        TxtUsuario.setText("Usuario");

        contraseñaInválida.setForeground(new java.awt.Color(255, 0, 0));

        Titulo.setFont(new java.awt.Font("Lucida Fax", 3, 18)); // NOI18N
        Titulo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Titulo.setText("Bienvenido a cuyofy");

        IniciarSesion.setBackground(new java.awt.Color(102, 153, 255));
        IniciarSesion.setText("Iniciar Sesion");
        IniciarSesion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                IniciarSesionActionPerformed(evt);
            }
        });

        TxtRegistro.setText("Si no tienes una cuenta ");

        Registro.setBackground(new java.awt.Color(102, 153, 255));
        Registro.setText("Registrarse");
        Registro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RegistroActionPerformed(evt);
            }
        });

        TxtFieldUsuario.setText("Ingrese Usuario");
        TxtFieldUsuario.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                TxtFieldUsuarioMousePressed(evt);
            }
        });

        barraSup.setBackground(new java.awt.Color(0, 51, 255));
        barraSup.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                barraSupMouseDragged(evt);
            }
        });
        barraSup.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                barraSupMousePressed(evt);
            }
        });

        exitButton.setBackground(new java.awt.Color(0, 51, 255));
        exitButton.setForeground(new java.awt.Color(102, 204, 255));
        exitButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        exitButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                exitButtonMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                exitButtonMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                exitButtonMouseExited(evt);
            }
        });

        jLabel1.setBackground(new java.awt.Color(255, 255, 255));
        jLabel1.setFont(new java.awt.Font("Dialog", 0, 24)); // NOI18N
        jLabel1.setText("x");

        javax.swing.GroupLayout exitButtonLayout = new javax.swing.GroupLayout(exitButton);
        exitButton.setLayout(exitButtonLayout);
        exitButtonLayout.setHorizontalGroup(
            exitButtonLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(exitButtonLayout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(jLabel1)
                .addContainerGap(23, Short.MAX_VALUE))
        );
        exitButtonLayout.setVerticalGroup(
            exitButtonLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(exitButtonLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addContainerGap(21, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout barraSupLayout = new javax.swing.GroupLayout(barraSup);
        barraSup.setLayout(barraSupLayout);
        barraSupLayout.setHorizontalGroup(
            barraSupLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(barraSupLayout.createSequentialGroup()
                .addComponent(exitButton, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        barraSupLayout.setVerticalGroup(
            barraSupLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(barraSupLayout.createSequentialGroup()
                .addComponent(exitButton, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 3, Short.MAX_VALUE))
        );

        TxtFieldcontraseña.setText("**********");
        TxtFieldcontraseña.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                TxtFieldcontraseñaMousePressed(evt);
            }
        });

        noExiste.setForeground(new java.awt.Color(255, 0, 0));

        TxtContraseña1.setText("Contraseña");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(TxtUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(TxtContraseña1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(TxtFieldUsuario, javax.swing.GroupLayout.DEFAULT_SIZE, 411, Short.MAX_VALUE)
                                    .addComponent(TxtFieldcontraseña)
                                    .addComponent(noExiste, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(contraseñaInválida)))
                            .addComponent(IniciarSesion, javax.swing.GroupLayout.Alignment.LEADING))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(0, 295, Short.MAX_VALUE)
                        .addComponent(TxtRegistro)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(Registro)
                        .addGap(34, 34, 34))))
            .addComponent(barraSup, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(Titulo, javax.swing.GroupLayout.DEFAULT_SIZE, 564, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(barraSup, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(49, 49, 49)
                .addComponent(Titulo, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(85, 85, 85)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(TxtUsuario)
                    .addComponent(TxtFieldUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(noExiste)
                .addGap(41, 41, 41)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(TxtFieldcontraseña, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(TxtContraseña1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(contraseñaInválida)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 32, Short.MAX_VALUE)
                .addComponent(IniciarSesion)
                .addGap(36, 36, 36)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(TxtRegistro)
                    .addComponent(Registro))
                .addGap(23, 23, 23))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void RegistroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RegistroActionPerformed
        Register registro = new Register();
        registro.setSize(570,500);
        registro.setLocationRelativeTo(null);
        registro.setVisible(true);
        noExiste.setText("");
        contraseñaInválida.setText("");
    }//GEN-LAST:event_RegistroActionPerformed
    
    
    private void IniciarSesionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_IniciarSesionActionPerformed
        
        verificacion=2;
        nombreUsuario = TxtFieldUsuario.getText();
        contraseña = new String(TxtFieldcontraseña.getPassword());
        
        if(db.existeUsuario(nombreUsuario)==false){
            noExiste.setText("No existe el nombre "+ nombreUsuario+ " en la base de datos");
            verificacion--;
        }
        if(db.verificarContraseña(nombreUsuario, contraseña) == false){
            verificacion--;
            contraseñaInválida.setText("La contraseña es inválida");
            
        }
        if(verificacion ==2){
            InterfazMain interfaz = new InterfazMain();
            this.setVisible(false);
            interfaz.setSize(730,530);
            interfaz.setLocationRelativeTo(null);
            interfaz.setVisible(true);
           
        }
    }//GEN-LAST:event_IniciarSesionActionPerformed

    private void barraSupMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_barraSupMousePressed
       
          // Evento de cuando el mouse se presiona
        xMouse = evt.getX();
        yMouse = evt.getY();
        
    }//GEN-LAST:event_barraSupMousePressed

    private void barraSupMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_barraSupMouseDragged
        
            //debemos considerar la posicion del mouse en la pantalla
        int x = evt.getXOnScreen();
        int y = evt.getYOnScreen();


     // Establecer lal locaclizacion de la ventana en el eje seleccionado
        this.setLocation(x - xMouse,y -  yMouse);
    }//GEN-LAST:event_barraSupMouseDragged

    private void exitButtonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_exitButtonMouseClicked
        // Evemtp click para cerrar ventana
        System.exit(0);
    }//GEN-LAST:event_exitButtonMouseClicked

    private void exitButtonMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_exitButtonMouseEntered
        // Evento cuando el mouse entre en el panel
        exitButton.setBackground(Color.red);
        exitButton.setForeground(Color.white);
    }//GEN-LAST:event_exitButtonMouseEntered

    private void exitButtonMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_exitButtonMouseExited
        // Evento cunado el mouse sale del panel
        exitButton.setBackground(Color.BLUE);
        exitButton.setForeground(Color.black);

        
    }//GEN-LAST:event_exitButtonMouseExited
 ///----------------------------------------------------------------------------
    
    /// PLACEHOLDER del LOGIN--------------------------------------------------------------
    private void TxtFieldUsuarioMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TxtFieldUsuarioMousePressed
        
        if (TxtFieldUsuario.getText().equals("Ingrese Usuario")) {
            TxtFieldUsuario.setText("");
            TxtFieldUsuario.setForeground(Color.black);
        }
        if (String.valueOf(TxtFieldcontraseña.getPassword()).isEmpty()) {
            TxtFieldcontraseña.setText("**********");
            TxtFieldcontraseña.setForeground(Color.gray);
        }
        
    }//GEN-LAST:event_TxtFieldUsuarioMousePressed

    private void TxtFieldcontraseñaMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TxtFieldcontraseñaMousePressed
   
        if (String.valueOf(TxtFieldcontraseña.getPassword()).equals("**********")) {
            TxtFieldcontraseña.setText("");
            TxtFieldcontraseña.setForeground(Color.black);
        }
        if (TxtFieldUsuario.getText().isEmpty()) {
            TxtFieldUsuario.setText("Ingrese Usuario");
            TxtFieldUsuario.setForeground(Color.gray);
        }
        
    }//GEN-LAST:event_TxtFieldcontraseñaMousePressed
///-------------------------------------------------------------------------------

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton IniciarSesion;
    private javax.swing.JToggleButton Registro;
    private javax.swing.JLabel Titulo;
    private javax.swing.JLabel TxtContraseña1;
    private javax.swing.JTextField TxtFieldUsuario;
    private javax.swing.JPasswordField TxtFieldcontraseña;
    private javax.swing.JLabel TxtRegistro;
    private javax.swing.JLabel TxtUsuario;
    private javax.swing.JPanel barraSup;
    private javax.swing.JLabel contraseñaInválida;
    private javax.swing.JPanel exitButton;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel noExiste;
    // End of variables declaration//GEN-END:variables
}
