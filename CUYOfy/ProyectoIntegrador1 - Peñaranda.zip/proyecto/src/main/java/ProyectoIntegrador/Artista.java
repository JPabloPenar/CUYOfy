package ProyectoIntegrador;
import java.util.ArrayList;

public class Artista extends Cuenta {
    
    public int cantidadOyentes;
    public String generoM;
    
    ArrayList<Album> listaAlbum = new ArrayList<>();
    
    public Artista( String nombreC, String generoM) {
        super(nombreC);
        this.generoM= generoM;
    }

    public String getGeneroM() {
        return generoM;
    }
    
    public int getCantidadOyentes() {
        return cantidadOyentes;
    }
    
  
   
}
    
    