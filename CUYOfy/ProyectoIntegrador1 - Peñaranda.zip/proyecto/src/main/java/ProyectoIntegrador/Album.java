package ProyectoIntegrador;
import java.util.Date;
import java.util.List;

public class Album extends PlayList {
    
    Date fecha;
    
    public Album(Date fecha, String nombre, String descripcion, List<Cancion> listaCanciones) {
        super(nombre, descripcion, listaCanciones);
        this.fecha = fecha;
    }

    public Date getFecha() {
        return fecha;
    }
}
