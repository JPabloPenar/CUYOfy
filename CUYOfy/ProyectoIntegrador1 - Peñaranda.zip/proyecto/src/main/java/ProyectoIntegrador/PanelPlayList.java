/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package ProyectoIntegrador;

import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.swing.DefaultListModel;
import javax.swing.JList;
import javax.swing.JOptionPane;




public class PanelPlayList extends javax.swing.JPanel {
    private DataBase db;
    private Reproductor repro;

    public PanelPlayList() {
        initComponents();
        db = new DataBase(); // Asegúrate de tener una instancia de DataBase


        repro = new Reproductor(); // Inicializar el reproductor
            // Configura el listener de selección de playlist
        listasDePlaylists.addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                String playlistSeleccionada = listasDePlaylists.getSelectedValue();
                cargarInformacionPlaylist(playlistSeleccionada);
            }
        });

        // Configuración de botones
        configurarReproduccion(); 
        cargarPlaylistsDefault();
        configurarNombrePlaylist();
        configurarDescripcionPlaylist();
        configurarEliminarCancion();
        configurarBusquedaCanciones();
        configurarAgregarCancionBuscada();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel15 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        listasDePlaylists = new javax.swing.JList<>();
        btnReproducir = new javax.swing.JButton();
        nombreDePlaylist = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        descripcionDePlayList = new javax.swing.JTextArea();
        jScrollPane3 = new javax.swing.JScrollPane();
        DefaultListModel<String> modeloCancionesAgregadas = new DefaultListModel<>();
        listaDeCancionesAgregadas = new JList<>(modeloCancionesAgregadas);
        buscadorDeCanciones = new javax.swing.JTextField();
        btnBuscarCancion = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane5 = new javax.swing.JScrollPane();
        listaMuestraLosResultadosDeBusqueda = new javax.swing.JList<>();
        btnAgregarCancionBuscada = new javax.swing.JButton();
        btnParaEliminarCanciones = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        btnPararMusica = new javax.swing.JButton();

        jPanel15.setBackground(new java.awt.Color(0, 51, 51));

        listasDePlaylists.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        jScrollPane1.setViewportView(listasDePlaylists);

        btnReproducir.setText("REPRODUCIR");

        descripcionDePlayList.setColumns(5);
        descripcionDePlayList.setRows(5);
        jScrollPane2.setViewportView(descripcionDePlayList);

        listaDeCancionesAgregadas.setModel(new javax.swing.DefaultListModel<String>() {
            String[] strings = { };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        jScrollPane3.setViewportView(listaDeCancionesAgregadas);

        btnBuscarCancion.setText("BUSCAR");

        jLabel1.setFont(new java.awt.Font("Lucida Fax", 3, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("TUS PLAYLISTS");

        listaMuestraLosResultadosDeBusqueda.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        jScrollPane5.setViewportView(listaMuestraLosResultadosDeBusqueda);

        btnAgregarCancionBuscada.setText("AGREGAR CANCION");

        btnParaEliminarCanciones.setText("eliminar cancion");

        jLabel2.setFont(new java.awt.Font("Segoe UI", 2, 12)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("SELECCIONE SU PLAYLIST:");

        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("NOMBRE DE LA PLAYLIST:");

        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("DESCRIPCION DE LA PLAYLIST:");

        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("CANCIONES DE LA PLAYLIST:");

        jLabel6.setFont(new java.awt.Font("Segoe UI", 2, 12)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("BUSCAR CANCIONES PARA AGREGAR:");

        btnPararMusica.setText("DETENER");

        javax.swing.GroupLayout jPanel15Layout = new javax.swing.GroupLayout(jPanel15);
        jPanel15.setLayout(jPanel15Layout);
        jPanel15Layout.setHorizontalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel15Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel15Layout.createSequentialGroup()
                        .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(33, 33, 33))
                    .addGroup(jPanel15Layout.createSequentialGroup()
                        .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jScrollPane5, javax.swing.GroupLayout.DEFAULT_SIZE, 356, Short.MAX_VALUE)
                            .addComponent(buscadorDeCanciones))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(btnBuscarCancion, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnAgregarCancionBuscada, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addContainerGap(36, Short.MAX_VALUE))
            .addGroup(jPanel15Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel15Layout.createSequentialGroup()
                        .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 216, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(139, 139, 139))
                    .addGroup(jPanel15Layout.createSequentialGroup()
                        .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel15Layout.createSequentialGroup()
                                .addComponent(nombreDePlaylist, javax.swing.GroupLayout.PREFERRED_SIZE, 212, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 287, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 177, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel15Layout.createSequentialGroup()
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 356, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(btnReproducir, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(btnPararMusica, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                            .addGroup(jPanel15Layout.createSequentialGroup()
                                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 212, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 204, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel15Layout.createSequentialGroup()
                                        .addGap(18, 18, 18)
                                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 260, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel15Layout.createSequentialGroup()
                                        .addGap(59, 59, 59)
                                        .addComponent(btnParaEliminarCanciones, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                        .addGap(0, 3, Short.MAX_VALUE))))
        );
        jPanel15Layout.setVerticalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel15Layout.createSequentialGroup()
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel15Layout.createSequentialGroup()
                        .addContainerGap(36, Short.MAX_VALUE)
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel15Layout.createSequentialGroup()
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel15Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel15Layout.createSequentialGroup()
                        .addGap(24, 24, 24)
                        .addComponent(btnReproducir)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnPararMusica)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel15Layout.createSequentialGroup()
                        .addComponent(nombreDePlaylist, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel4))
                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel15Layout.createSequentialGroup()
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnParaEliminarCanciones))
                    .addGroup(jPanel15Layout.createSequentialGroup()
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(buscadorDeCanciones, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnBuscarCancion))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnAgregarCancionBuscada)
                    .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel15, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jPanel15, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 587, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 26, Short.MAX_VALUE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 26, Short.MAX_VALUE)))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 643, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 60, Short.MAX_VALUE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 61, Short.MAX_VALUE)))
        );
    }// </editor-fold>//GEN-END:initComponents
// </editor-fold>                        
        // Método para inicializar las playlists con selección y carga de datos

        private void cargarPlaylistsDefault() {
            DefaultListModel<String> modeloPlaylists = new DefaultListModel<>();
            List<String> nombresPlaylists = db.obtenerNombresDePlaylists(); // Nuevo método que obtiene los nombres de las playlists

            for (String nombre : nombresPlaylists) {
                modeloPlaylists.addElement(nombre);
            }
            listasDePlaylists.setModel(modeloPlaylists);
        }


        // Método para cargar información de la playlist en los campos correspondientes
        private void cargarInformacionPlaylist(String nombrePlaylist) {
            PlayList playlist = db.obtenerPlaylist(nombrePlaylist);
            if (playlist != null) {
                nombreDePlaylist.setText(playlist.getNombre());
                descripcionDePlayList.setText(playlist.getGenero());

                // Cargar canciones en la lista de canciones agregadas
                DefaultListModel<String> modeloCanciones = new DefaultListModel<>();
                for (Cancion cancion : playlist.getCanciones()) {
                    modeloCanciones.addElement(cancion.getNombre());
                }
                listaDeCancionesAgregadas.setModel(modeloCanciones);
            }
        }

        private void configurarNombrePlaylist() {
            nombreDePlaylist.addFocusListener(new FocusAdapter() {
                @Override
                public void focusLost(FocusEvent e) {
                    String nuevoNombre = nombreDePlaylist.getText().trim();
                    String nombreActual = listasDePlaylists.getSelectedValue();

                    if (nombreActual != null && !nuevoNombre.isEmpty()) {
                        db.actualizarNombrePlaylist(nombreActual, nuevoNombre);
                        cargarPlaylistsDefault(); // Recarga la lista de playlists con el nombre actualizado

                        // Selecciona automáticamente la playlist con el nuevo nombre
                        listasDePlaylists.setSelectedValue(nuevoNombre, true);
                    }
                }
            });
        }

        private void configurarDescripcionPlaylist() {
            descripcionDePlayList.addFocusListener(new FocusAdapter() {
                @Override
                public void focusLost(FocusEvent e) {
                    String nuevaDescripcion = descripcionDePlayList.getText().trim();
                    String playlistSeleccionada = listasDePlaylists.getSelectedValue();
                    if (playlistSeleccionada != null) {
                        db.actualizarDescripcionPlaylist(playlistSeleccionada, nuevaDescripcion);
                    }
                }
            });
        }
        private void configurarEliminarCancion() {
            btnParaEliminarCanciones.addActionListener(e -> {
                String cancionSeleccionada = listaDeCancionesAgregadas.getSelectedValue();
                String playlistSeleccionada = listasDePlaylists.getSelectedValue();
                if (cancionSeleccionada != null && playlistSeleccionada != null) {
                    db.eliminarCancionDePlaylist(playlistSeleccionada, cancionSeleccionada);
                    cargarInformacionPlaylist(playlistSeleccionada); // Recarga la lista sin la canción eliminada
                }
            });
        }

        private void configurarBusquedaCanciones() {
            btnBuscarCancion.addActionListener(e -> {
                String textoBusqueda = buscadorDeCanciones.getText().trim();
                if (!textoBusqueda.isEmpty()) {
                    List<Cancion> resultadosBusqueda = db.buscarCanciones(textoBusqueda);
                    DefaultListModel<String> modeloResultados = new DefaultListModel<>();
                    for (Cancion cancion : resultadosBusqueda) {
                        modeloResultados.addElement(cancion.getNombre());
                    }
                    listaMuestraLosResultadosDeBusqueda.setModel(modeloResultados);
                }
            });
        }

        private void configurarAgregarCancionBuscada() {
            btnAgregarCancionBuscada.addActionListener(e -> {
                String cancionSeleccionada = listaMuestraLosResultadosDeBusqueda.getSelectedValue();
                String playlistSeleccionada = listasDePlaylists.getSelectedValue();

                if (cancionSeleccionada != null && playlistSeleccionada != null) {
                    DefaultListModel<String> modeloCanciones = (DefaultListModel<String>) listaDeCancionesAgregadas.getModel();
                    if (modeloCanciones.size() < 5) {
                        db.agregarCancionAPlaylist(playlistSeleccionada, cancionSeleccionada);
                        modeloCanciones.addElement(cancionSeleccionada); // Agrega la canción directamente al modelo
                    } else {
                        JOptionPane.showMessageDialog(this, "No se pueden agregar más de 5 canciones.");
                    }
                }
            });
        }
        private void configurarReproduccion() {
            btnReproducir.addActionListener(e -> {
                String playlistSeleccionada = listasDePlaylists.getSelectedValue();
                if (playlistSeleccionada != null) {
                    List<Cancion> canciones = db.obtenerPlaylist(playlistSeleccionada).getCanciones();
                    if (!canciones.isEmpty()) {
                        repro.reproducirPlaylist(canciones); // Iniciar la reproducción
                    } else {
                        JOptionPane.showMessageDialog(this, "La playlist no tiene canciones.");
                    }
                }
            });

            btnPararMusica.addActionListener(e -> repro.detener()); // Detener la reproducción
        }
        
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAgregarCancionBuscada;
    private javax.swing.JButton btnBuscarCancion;
    private javax.swing.JButton btnParaEliminarCanciones;
    private javax.swing.JButton btnPararMusica;
    private javax.swing.JButton btnReproducir;
    private javax.swing.JTextField buscadorDeCanciones;
    private javax.swing.JTextArea descripcionDePlayList;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JList<String> listaDeCancionesAgregadas;
    private javax.swing.JList<String> listaMuestraLosResultadosDeBusqueda;
    private javax.swing.JList<String> listasDePlaylists;
    private javax.swing.JTextField nombreDePlaylist;
    // End of variables declaration//GEN-END:variables
}
