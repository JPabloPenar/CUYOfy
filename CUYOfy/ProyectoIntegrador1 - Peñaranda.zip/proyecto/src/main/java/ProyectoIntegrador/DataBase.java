
package ProyectoIntegrador;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


public class DataBase {
    private static final String url = "jdbc:sqlite:C:/Users/"+ProyectoIntegrador1.user+"/Music/CUYOfy/1DATABASE/mydatabase.db";
    private static Connection connection = null;
       
    public static Connection getConnection() {
        if (connection == null) {
            try {
                connection = DriverManager.getConnection(url);
                System.out.println("Conectado a SQLite");
            } catch (SQLException e) {
                System.out.println("Error al conectar: " + e.getMessage());
            }
        }
        return connection;
    }
    
public static void borrarTodasLasTablas() {
    String[] tablas = {"megustas", "reproducciones", "canciones", "usuarios"};

    try (Connection conn = DriverManager.getConnection(url);
         Statement stmt = conn.createStatement()) {
        for (String tabla : tablas) {
            String sqlDrop = "DROP TABLE IF EXISTS " + tabla;
            stmt.execute(sqlDrop);
            System.out.println("Tabla '" + tabla + "' eliminada.");
        }
    } catch (SQLException e) {
        System.err.println("Error al borrar las tablas: " + e.getMessage());
    }
}
    public static void crearTablas() {
    crearTablaUsuarios(url);
    crearTablaCanciones(url);
    crearTablaMeGusta(url);
    crearTablaReproducciones(url);
    crearTablaPlaylists(url);
    crearTablaPlaylistCanciones(url);
}

public static void eliminarTodosLosRegistros() {
    String[] tablas = { /*"megustas", "reproducciones", */"canciones" /*, "usuarios" */};

    try (Connection conn = DriverManager.getConnection(url);
         Statement stmt = conn.createStatement()) {
        for (String tabla : tablas) {
            String sqlDelete = "DELETE FROM " + tabla;
            int filasAfectadas = stmt.executeUpdate(sqlDelete);
            System.out.println("Se han eliminado " + filasAfectadas + " registros de la tabla '" + tabla + "'.");
        }
    } catch (SQLException e) {
        System.err.println("Error al eliminar registros de las tablas: " + e.getMessage());
    }
}  
public static void crearTablaReproducciones(String url) {
    String sqlCreate = "CREATE TABLE IF NOT EXISTS reproducciones ("
            + "id INTEGER PRIMARY KEY AUTOINCREMENT,"
            + "usuario TEXT NOT NULL,"
            + "nombre_cancion TEXT NOT NULL,"
            + "fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP,"
            + "FOREIGN KEY (nombre_cancion) REFERENCES canciones(nombre)"
            + ");";

    try (Connection conn = DriverManager.getConnection(url);
         Statement stmt = conn.createStatement()) {
        
        stmt.execute(sqlCreate);
        System.out.println("Tabla 'reproducciones' creada o verificada.");
        
    } catch (SQLException e) {
        System.err.println("Error al crear la tabla 'reproducciones': " + e.getMessage());
    }
}


public static void crearTablaUsuarios(String url) {
    String sqlCreate = "CREATE TABLE IF NOT EXISTS usuarios ("
            + "id INTEGER PRIMARY KEY AUTOINCREMENT,"
            + "nombre TEXT NOT NULL UNIQUE,"
            + "contrasena TEXT NOT NULL"
            + ");";

    try (Connection conn = DriverManager.getConnection(url);
         Statement stmt = conn.createStatement()) {

        stmt.execute(sqlCreate);
        System.out.println("Tabla 'usuarios' creada o verificada.");

    } catch (SQLException e) {
        System.err.println("Error al crear la tabla 'usuarios': " + e.getMessage());
    }
}

public static void crearTablaCanciones(String url) {
    String sqlCreate = "CREATE TABLE IF NOT EXISTS canciones ("
            + "id INTEGER PRIMARY KEY AUTOINCREMENT,"
            + "nombre TEXT NOT NULL,"
            + "duracion INTEGER NOT NULL,"
            + "artista TEXT NOT NULL,"
            + "album TEXT NOT NULL"
            + ");";

    try (Connection conn = DriverManager.getConnection(url);
         Statement stmt = conn.createStatement()) {

        stmt.execute(sqlCreate);
        System.out.println("Tabla 'canciones' creada o verificada.");

    } catch (SQLException e) {
        System.err.println("Error al crear la tabla 'canciones': " + e.getMessage());
    }
}

public static void crearTablaMeGusta(String url) {
    String sqlCreate = "CREATE TABLE IF NOT EXISTS megustas ("
            + "usuario TEXT NOT NULL,"
            + "nombre_cancion TEXT NOT NULL,"
            + "FOREIGN KEY (nombre_cancion) REFERENCES canciones(nombre) ON DELETE CASCADE"
            + ");";

    try (Connection conn = DriverManager.getConnection(url);
         Statement stmt = conn.createStatement()) {

        stmt.execute(sqlCreate);
        System.out.println("Tabla 'megustas' creada o verificada.");

    } catch (SQLException e) {
        System.err.println("Error al crear la tabla 'megustas': " + e.getMessage());
    }
}  
       
    public static void guardarUsuarioEnBaseDeDatos(String nombreUsuario, String contraseña) {
        String sqlInsert = "INSERT INTO usuarios (nombre, contrasena) VALUES (?, ?)";

        try (Connection conn = DriverManager.getConnection(url);
         PreparedStatement pstmt = conn.prepareStatement(sqlInsert)) {
            pstmt.setString(1, nombreUsuario);
            pstmt.setString(2, contraseña);
            pstmt.executeUpdate();
            System.out.println("Usuario '" + nombreUsuario + "' registrado exitosamente.");
        } catch (SQLException e) {
            System.err.println("Error al guardar el usuario: " + e.getMessage());
        }
    }    
       
    public static boolean existeUsuario(String nombreUsuario) {
        String sqlQuery = "SELECT COUNT(*) FROM usuarios WHERE nombre = ?";

        try (PreparedStatement pstmt = getConnection().prepareStatement(sqlQuery)) {
            pstmt.setString(1, nombreUsuario);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
        } catch (SQLException e) {
            System.err.println("Error al verificar el usuario: " + e.getMessage());
        }
        return false;
    }

public static boolean verificarContraseña(String nombreUsuario, String contrasenaIngresada) {
    boolean esCorrecta = false;

    String sql = "SELECT contrasena FROM usuarios WHERE nombre = ?";

    // Abre una nueva conexión cada vez que se llama el método
    try (Connection conn = DriverManager.getConnection(url);
         PreparedStatement pstmt = conn.prepareStatement(sql)) {
        
        pstmt.setString(1, nombreUsuario);
        
        try (ResultSet rs = pstmt.executeQuery()) {
            if (rs.next()) {
                String contrasenaAlmacenada = rs.getString("contrasena");
                esCorrecta = contrasenaAlmacenada != null && contrasenaAlmacenada.equals(contrasenaIngresada);
            }
        }
        
    } catch (SQLException e) {
        System.err.println("Error en la conexión o en la consulta: " + e.getMessage());
    }

    return esCorrecta;
}

    public static void crearTablaMeGusta() {
  
    String sqlCreate = "CREATE TABLE IF NOT EXISTS megustas ("
            + "id INTEGER PRIMARY KEY AUTOINCREMENT,"
            + "usuario TEXT NOT NULL,"
            + "nombre_cancion TEXT NOT NULL,"
            + "FOREIGN KEY (nombre_cancion) REFERENCES canciones(nombre)"
            + ");";

    try (Connection conn = DriverManager.getConnection(url);
         Statement stmt = conn.createStatement()) {
        
        stmt.execute(sqlCreate);
        System.out.println("Tabla 'megustas' creada o verificada.");
        
    } catch (SQLException e) {
        System.err.println("Error al crear la tabla: " + e.getMessage());
    }
}
    public static void crearTablaPlaylists(String url) {
    String sqlCreate = "CREATE TABLE IF NOT EXISTS Playlists ("
            + "id INTEGER PRIMARY KEY AUTOINCREMENT, "
            + "nombre TEXT NOT NULL UNIQUE, "
            + "descripcion TEXT"
            + ");";
    try (Connection conn = DriverManager.getConnection(url);
         Statement stmt = conn.createStatement()) {
        stmt.execute(sqlCreate);
        System.out.println("Tabla 'Playlists' creada o verificada.");
    } catch (SQLException e) {
        System.err.println("Error al crear la tabla 'Playlists': " + e.getMessage());
    }
}
public static void crearTablaPlaylistCanciones(String url) {
    String sqlCreate = "CREATE TABLE IF NOT EXISTS Playlist_Canciones ("
            + "playlist_id INTEGER NOT NULL, "
            + "cancion_id INTEGER NOT NULL, "
            + "FOREIGN KEY (playlist_id) REFERENCES Playlists(id) ON DELETE CASCADE, "
            + "FOREIGN KEY (cancion_id) REFERENCES Canciones(id) ON DELETE CASCADE"
            + ");";
    try (Connection conn = DriverManager.getConnection(url);
         Statement stmt = conn.createStatement()) {
        stmt.execute(sqlCreate);
        System.out.println("Tabla 'Playlist_Canciones' creada o verificada.");
    } catch (SQLException e) {
        System.err.println("Error al crear la tabla 'Playlist_Canciones': " + e.getMessage());
    }
}
    public static void guardarCancion(String nombre, long duracion, String artista, String album) {
       
        String sqlInsert = "INSERT INTO canciones (nombre, duracion, artista, album) VALUES (?, ?, ?, ?)";

        try (Connection conn = DriverManager.getConnection(url);
             PreparedStatement pstmt = conn.prepareStatement(sqlInsert)) {

            pstmt.setString(1, nombre);
            pstmt.setLong(2, duracion);
            pstmt.setString(3, artista);
            pstmt.setString(4, album);

            pstmt.executeUpdate();
            System.out.println("Cancion '" + nombre + "' guardada en la base de datos.");

        } catch (SQLException e) {
            System.err.println("Error al guardar la canción: " + e.getMessage());
        }
    }
    
public static void agregarMeGusta(String nombreUsuario, String nombreCancion) {
   
    String sqlInsert = "INSERT INTO megustas (usuario, nombre_cancion) VALUES (?, ?)";

    try (Connection conn = DriverManager.getConnection(url);
         PreparedStatement pstmt = conn.prepareStatement(sqlInsert)) {
        
        pstmt.setString(1, nombreUsuario);
        pstmt.setString(2, nombreCancion);

        pstmt.executeUpdate();
        System.out.println("Se ha añadido un 'Me gusta' de " + nombreUsuario + " a la canción: " + nombreCancion);
        
    } catch (SQLException e) {
        System.err.println("Error al agregar 'Me gusta': " + e.getMessage());
    }
}
public static void agregarReproduccion(String nombreUsuario, String nombreCancion) {
    String sqlInsert = "INSERT INTO reproducciones (usuario, nombre_cancion) VALUES (?, ?)";

    try (Connection conn = DriverManager.getConnection(url);
         PreparedStatement pstmt = conn.prepareStatement(sqlInsert)) {
        
        pstmt.setString(1, nombreUsuario);
        pstmt.setString(2, nombreCancion);
        pstmt.executeUpdate();
        System.out.println("Se ha añadido una reproducción de " + nombreUsuario + " a la canción: " + nombreCancion);
        
    } catch (SQLException e) {
        System.err.println("Error al agregar la reproducción: " + e.getMessage());
    }
}

public static int contarMeGustas(String nombreCancion) {

    String sqlQuery = "SELECT COUNT(*) FROM megustas WHERE nombre_cancion = ?";
    int totalMeGustas = 0;

    try (Connection conn = DriverManager.getConnection(url);
         PreparedStatement pstmt = conn.prepareStatement(sqlQuery)) {
        
        pstmt.setString(1, nombreCancion);
        
        ResultSet rs = pstmt.executeQuery();
        
        if (rs.next()) {
            totalMeGustas = rs.getInt(1); // Obtener el conteo de "Me gusta"
        }
        
    } catch (SQLException e) {
        System.err.println("Error al contar 'Me gusta': " + e.getMessage());
    }
    
    return totalMeGustas; // Retornar el total de "Me gusta"
}
public static int contarReproducciones(String nombreCancion) {
    String sqlQuery = "SELECT COUNT(*) FROM reproducciones WHERE nombre_cancion = ?";
    int totalReproducciones = 0;

    try (Connection conn = DriverManager.getConnection(url);
         PreparedStatement pstmt = conn.prepareStatement(sqlQuery)) {
        
        pstmt.setString(1, nombreCancion);
        
        ResultSet rs = pstmt.executeQuery();
        
        if (rs.next()) {
            totalReproducciones = rs.getInt(1); // Obtener el conteo de reproducciones
        }
        
    } catch (SQLException e) {
        System.err.println("Error al contar reproducciones: " + e.getMessage());
    }
    
    return totalReproducciones; // Retornar el total de reproducciones
}

public static ArrayList<String> obtenerMeGustasPorUsuario(String nombreUsuario) {
    ArrayList<String> meGustas = new ArrayList<>();
  
    String sqlQuery = "SELECT nombre_cancion FROM megustas WHERE usuario = ?";

    System.out.println("Conectando a la base de datos para obtener 'Me gusta'...");

    try (Connection conn = DriverManager.getConnection(url);
         PreparedStatement pstmt = conn.prepareStatement(sqlQuery)) {

        pstmt.setString(1, nombreUsuario);
        System.out.println("Ejecutando consulta para el usuario: " + nombreUsuario);

        ResultSet rs = pstmt.executeQuery();

        while (rs.next()) {
            String nombreCancion = rs.getString("nombre_cancion");
            meGustas.add(nombreCancion);
            System.out.println("Me gusta encontrado: " + nombreCancion); // Confirmar cada canción obtenida
        }
    } catch (SQLException e) {
        System.err.println("Error al obtener 'Me gusta': " + e.getMessage());
    }

    System.out.println("Total de 'Me gusta' obtenidos: " + meGustas.size());
    return meGustas;
}
public static void eliminarMeGusta(String nombreUsuario, String nombreCancion) {
    String sqlDelete = "DELETE FROM megustas WHERE usuario = ? AND nombre_cancion = ?";
    try (Connection conn = DriverManager.getConnection(url);
         PreparedStatement pstmt = conn.prepareStatement(sqlDelete)) {
        pstmt.setString(1, nombreUsuario);
        pstmt.setString(2, nombreCancion);
        pstmt.executeUpdate();
        System.out.println("Se ha eliminado el 'Me gusta' de " + nombreUsuario + " para la canción: " + nombreCancion);
    } catch (SQLException e) {
        System.err.println("Error al eliminar 'Me gusta': " + e.getMessage());
    }
}

public Cancion obtenerCancion(String nombreCancion) {
    // Lógica para obtener la canción de la base de datos
    // Esto podría ser una consulta SQL que busque la canción en la tabla de canciones
    Cancion cancion = null;
    String sql = "SELECT * FROM Canciones WHERE nombre = ?";
    try (Connection conn = DriverManager.getConnection(url);
         PreparedStatement pstmt = conn.prepareStatement(sql)) {
        pstmt.setString(1, nombreCancion);
        ResultSet rs = pstmt.executeQuery();
        if (rs.next()) {
            String artista = rs.getString("artista");
            long duracion = rs.getLong("duracion");
            cancion = new Cancion(nombreCancion, duracion, artista);
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
    return cancion;
}

public Object[] obtenerCancionPorNombre(String nombreCancion) {
    Cancion cancion = null;
    String path = null;
    try {
        String query = "SELECT * FROM Canciones WHERE nombre = ?";
        PreparedStatement stmt = connection.prepareStatement(query);
        stmt.setString(1, nombreCancion);
        ResultSet rs = stmt.executeQuery();
        
        if (rs.next()) {
            String nombre = rs.getString("nombre");
            long duracion = rs.getLong("duracion");
            String artista = rs.getString("artista");
            path = rs.getString("ruta");  // Obtiene la ruta del archivo desde la base de datos
            
            cancion = new Cancion(nombre, duracion, artista);  // Crea la instancia de Cancion
        }
        rs.close();
        stmt.close();
    } catch (SQLException e) {
        e.printStackTrace();
    }
    return new Object[]{cancion, path};  // Retorna la canción y su ruta
}

public PlayList obtenerPlaylist(String nombrePlaylist) {
    PlayList playlist = null;
    List<Cancion> canciones = new ArrayList<>();
    String sqlPlaylist = "SELECT * FROM Playlists WHERE nombre = ?";
    String sqlCanciones = "SELECT c.* FROM Canciones c "
                        + "JOIN Playlist_Canciones pc ON c.id = pc.cancion_id "
                        + "JOIN Playlists p ON pc.playlist_id = p.id "
                        + "WHERE p.nombre = ?";

    try (Connection conn = DriverManager.getConnection(url);
         PreparedStatement pstmtPlaylist = conn.prepareStatement(sqlPlaylist)) {
        
        pstmtPlaylist.setString(1, nombrePlaylist);
        ResultSet rsPlaylist = pstmtPlaylist.executeQuery();

        if (rsPlaylist.next()) {
            String descripcion = rsPlaylist.getString("descripcion");

            // Obtener canciones de la playlist
            try (PreparedStatement pstmtCanciones = conn.prepareStatement(sqlCanciones)) {
                pstmtCanciones.setString(1, nombrePlaylist);
                ResultSet rsCanciones = pstmtCanciones.executeQuery();

                while (rsCanciones.next()) {
                    String nombreCancion = rsCanciones.getString("nombre");
                    String artista = rsCanciones.getString("artista");
                    long duracion = rsCanciones.getLong("duracion");
                    Cancion cancion = new Cancion(nombreCancion, duracion, artista);
                    canciones.add(cancion);
                }
            }

            // Crear la instancia de PlayList con las canciones obtenidas
            playlist = new PlayList(nombrePlaylist, descripcion, canciones);
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }

    return playlist;
}

public List<String> obtenerNombresDePlaylists() {
    List<String> nombres = new ArrayList<>();
    String sql = "SELECT nombre FROM Playlists";
    
    try (Connection conn = DriverManager.getConnection(url);
         Statement stmt = conn.createStatement();
         ResultSet rs = stmt.executeQuery(sql)) {
        
        while (rs.next()) {
            nombres.add(rs.getString("nombre"));
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
    return nombres;
}
public void actualizarNombrePlaylist(String nombreActual, String nuevoNombre) {
    String sql = "UPDATE Playlists SET nombre = ? WHERE nombre = ?";
    try (Connection conn = DriverManager.getConnection(url);
         PreparedStatement pstmt = conn.prepareStatement(sql)) {
        pstmt.setString(1, nuevoNombre);
        pstmt.setString(2, nombreActual);
        int filasActualizadas = pstmt.executeUpdate();
        
        if (filasActualizadas > 0) {
            System.out.println("Nombre de playlist actualizado: " + nuevoNombre);
        } else {
            System.out.println("No se encontró la playlist con el nombre: " + nombreActual);
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
}

public void actualizarDescripcionPlaylist(String nombrePlaylist, String nuevaDescripcion) {
    String sql = "UPDATE Playlists SET descripcion = ? WHERE nombre = ?";
    try (Connection conn = DriverManager.getConnection(url);
         PreparedStatement pstmt = conn.prepareStatement(sql)) {
        pstmt.setString(1, nuevaDescripcion);
        pstmt.setString(2, nombrePlaylist);
        pstmt.executeUpdate();
    } catch (SQLException e) {
        e.printStackTrace();
    }
}
public void eliminarCancionDePlaylist(String nombrePlaylist, String nombreCancion) {
    String sql = "DELETE FROM Playlist_Canciones WHERE playlist_id = (SELECT id FROM Playlists WHERE nombre = ?) "
               + "AND cancion_id = (SELECT id FROM Canciones WHERE nombre = ?)";
    try (Connection conn = DriverManager.getConnection(url);
         PreparedStatement pstmt = conn.prepareStatement(sql)) {
        pstmt.setString(1, nombrePlaylist);
        pstmt.setString(2, nombreCancion);
        pstmt.executeUpdate();
    } catch (SQLException e) {
        e.printStackTrace();
    }
}

public List<Cancion> buscarCanciones(String textoBusqueda) {
    List<Cancion> canciones = new ArrayList<>();
    String sql = "SELECT * FROM Canciones WHERE nombre LIKE ?";
    try (Connection conn = DriverManager.getConnection(url);
         PreparedStatement pstmt = conn.prepareStatement(sql)) {
        pstmt.setString(1, "%" + textoBusqueda + "%");
        ResultSet rs = pstmt.executeQuery();

        while (rs.next()) {
            String nombre = rs.getString("nombre");
            String artista = rs.getString("artista");
            long duracion = rs.getLong("duracion");
            canciones.add(new Cancion(nombre, duracion, artista));
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
    return canciones;
}
public void crearPlaylistsIniciales() {
    // Verifica si ya existen playlists en la base de datos
    if (obtenerIdPlaylist("Playlist 1") == -1) {
        crearPlaylist("Playlist 1", "Descripción de Playlist 1");
    }
    if (obtenerIdPlaylist("Playlist 2") == -1) {
        crearPlaylist("Playlist 2", "Descripción de Playlist 2");
    }
    if (obtenerIdPlaylist("Playlist 3") == -1) {
        crearPlaylist("Playlist 3", "Descripción de Playlist 3");
    }
    if (obtenerIdPlaylist("Playlist 4") == -1) {
        crearPlaylist("Playlist 4", "Descripción de Playlist 4");
    }
    if (obtenerIdPlaylist("Playlist 5") == -1) {
        crearPlaylist("Playlist 5", "Descripción de Playlist 5");
    }
}
public void crearPlaylist(String nombre, String descripcion) {
    String sql = "INSERT INTO Playlists (nombre, descripcion) VALUES (?, ?)";
    try (Connection conn = DriverManager.getConnection(url);
         PreparedStatement pstmt = conn.prepareStatement(sql)) {
        pstmt.setString(1, nombre);
        pstmt.setString(2, descripcion);
        pstmt.executeUpdate();
        System.out.println("Playlist '" + nombre + "' creada.");
    } catch (SQLException e) {
        System.err.println("Error al crear la playlist: " + e.getMessage());
    }
}

public void crearCancion(String nombre, int duracion, String artista, String album) {
    String sql = "INSERT INTO Canciones (nombre, duracion, artista, album) VALUES (?, ?, ?, ?)";
    try (Connection conn = DriverManager.getConnection(url);
         PreparedStatement pstmt = conn.prepareStatement(sql)) {
        pstmt.setString(1, nombre);
        pstmt.setInt(2, duracion);
        pstmt.setString(3, artista);
        pstmt.setString(4, album);
        pstmt.executeUpdate();
        System.out.println("Canción '" + nombre + "' creada.");
    } catch (SQLException e) {
        System.err.println("Error al crear la canción: " + e.getMessage());
    }
}

public void agregarCancionAPlaylist(String nombrePlaylist, String nombreCancion) {
    int playlistId = obtenerIdPlaylist(nombrePlaylist);
    int cancionId = obtenerIdCancion(nombreCancion);

    // Si la playlist no existe, crea una nueva entrada en la tabla Playlists
    if (playlistId == -1) {
        crearPlaylist(nombrePlaylist, "Descripción por defecto"); // Puedes agregar una descripción
        playlistId = obtenerIdPlaylist(nombrePlaylist);
    }

    // Si la canción no existe, crea una nueva entrada en la tabla Canciones
    if (cancionId == -1) {
        crearCancion(nombreCancion, 200, "Artista por defecto", "Álbum por defecto"); // Valores por defecto
        cancionId = obtenerIdCancion(nombreCancion);
    }

    if (playlistId == -1 || cancionId == -1) {
        System.err.println("Error: No se pudo crear la playlist o la canción.");
        return;
    }

    String sql = "INSERT INTO Playlist_Canciones (playlist_id, cancion_id) VALUES (?, ?)";
    try (Connection conn = DriverManager.getConnection(url);
         PreparedStatement pstmt = conn.prepareStatement(sql)) {
        pstmt.setInt(1, playlistId);
        pstmt.setInt(2, cancionId);
        pstmt.executeUpdate();
    } catch (SQLException e) {
        e.printStackTrace();
    }
}
// Método para inicializar las playlists con selección y carga de datos

public void guardarPlayList(PlayList playlist) {
    String sql = "INSERT INTO Playlists (nombre, descripcion) VALUES (?, ?)";
    try (Connection conn = DriverManager.getConnection(url);
         PreparedStatement pstmt = conn.prepareStatement(sql)) {
        pstmt.setString(1, playlist.getNombre());
        pstmt.setString(2, playlist.getGenero());
        pstmt.executeUpdate();

        // Guardar canciones de la playlist
        for (Cancion cancion : playlist.getCanciones()) {
            String sqlCancion = "INSERT INTO Playlist_Canciones (playlist_id, cancion_id) VALUES (?, ?)";
            try (PreparedStatement pstmtCancion = conn.prepareStatement(sqlCancion)) {
                pstmtCancion.setInt(1, obtenerIdPlaylist(playlist.getNombre())); // Método para obtener el ID de la playlist
                pstmtCancion.setInt(2, obtenerIdCancion(cancion.getNombre()));  // Método para obtener el ID de la canción
                pstmtCancion.executeUpdate();
            }
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
}
public int obtenerIdCancion(String nombreCancion) {
    int idCancion = -1; // Valor predeterminado si no se encuentra
    String sql = "SELECT id FROM Canciones WHERE nombre = ?";
    try (Connection conn = DriverManager.getConnection(url);
         PreparedStatement pstmt = conn.prepareStatement(sql)) {
        pstmt.setString(1, nombreCancion);
        ResultSet rs = pstmt.executeQuery();
        if (rs.next()) {
            idCancion = rs.getInt("id");
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
    return idCancion;
}
public int obtenerIdPlaylist(String nombrePlaylist) {
    int idPlaylist = -1; // Valor predeterminado si no se encuentra
    String sql = "SELECT id FROM Playlists WHERE nombre = ?";
    try (Connection conn = DriverManager.getConnection(url);
         PreparedStatement pstmt = conn.prepareStatement(sql)) {
        pstmt.setString(1, nombrePlaylist);
        ResultSet rs = pstmt.executeQuery();
        if (rs.next()) {
            idPlaylist = rs.getInt("id");
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
    return idPlaylist;

}

public static String devolverArtista(String nombre_cancion) {
    String artista = null;
    String sql = "SELECT artista FROM canciones WHERE nombre = ?"; // Agregamos la cláusula WHERE

    try (Connection conn = DriverManager.getConnection(url);
         PreparedStatement pstmt = conn.prepareStatement(sql)) {
        
        pstmt.setString(1, nombre_cancion);
        
        try (ResultSet rs = pstmt.executeQuery()) {
            if (rs.next()) {
                artista = rs.getString("artista"); // Usamos la variable externa
            }
        }
        
    } catch (SQLException e) {
        System.err.println("Error en la conexión o en la consulta: " + e.getMessage());
    }
    
    return artista; // Devolvemos el artista encontrado
}
public static long devolverDuracion(String nombre_cancion) {
    long duracion = 0;
    String sql = "SELECT duracion FROM canciones WHERE nombre = ?"; // Agregamos la cláusula WHERE

    try (Connection conn = DriverManager.getConnection(url);
         PreparedStatement pstmt = conn.prepareStatement(sql)) {
        
        pstmt.setString(1, nombre_cancion);
        
        try (ResultSet rs = pstmt.executeQuery()) {
            if (rs.next()) {
                duracion = rs.getLong("duracion"); // Usamos la variable externa
            }
        }
        
    } catch (SQLException e) {
        System.err.println("Error en la conexión o en la consulta: " + e.getMessage());
    }
    
    return duracion; // Devolvemos el artista encontrado
}


}
     
     
    
    

