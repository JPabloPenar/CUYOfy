package ProyectoIntegrador;

import java.util.List;

public class PlayList extends Lista {
    String genero;
    String nombre;
    private List<Cancion> listaCanciones;
    double duracion=0;
    

        // Constructor 
    public PlayList(String nombre, String descripcion, List<Cancion> listaCanciones) {
        this.nombre = nombre;
        this.genero = descripcion;
        this.listaCanciones = listaCanciones;
        this.duracion = calcularDuracion();
    }

    // Método para obtener la lista de canciones
    public List<Cancion> getCanciones() {
        return listaCanciones;
    }

    // Método para calcular la duración total de la playlist
    private double calcularDuracion() {
        return listaCanciones.stream().mapToDouble(Cancion::getDuracion).sum();
    }
    public double getDuracion() {
        return duracion;
    }

    public String getGenero() {
        return genero;
    }

    public String getNombre() {
        return nombre;
    }
    
    
        @Override
        public void addCancion(Cancion cancion){
            super.addCancion(cancion);
            duracion= duracion + cancion.getDuracion();
        }
}
