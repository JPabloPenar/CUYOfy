package ProyectoIntegrador;

public class MeGusta extends Lista{
    
    DataBase db = new DataBase();
    public MeGusta() {
        super();
        
    }
    
    public boolean isLiked(Cancion cancion){
        return canciones.contains(cancion);
}
    @Override
    public void addCancion(Cancion cancion){
     //DataBase.agregarMeGusta(cancion.getNombre(), Login.nombreUsuario);
     super.addCancion(cancion);
    }
    
    
  
}
